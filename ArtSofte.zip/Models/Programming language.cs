﻿using System;
namespace Artsofte.Controllers

{
    public class Programminglanguage
    {
     public Guid Id { get; set; }
      public string Name { get; set; }
    }
}
